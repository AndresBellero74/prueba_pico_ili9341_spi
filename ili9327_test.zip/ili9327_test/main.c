#include "pico/stdlib.h"

#define LCD_RS   8
#define LCD_CS   9
#define LCD_WR   10
#define LCD_RD   12  // RD fijo en HIGH

const uint8_t lcd_data_pins[8] = {0,1,2,3,4,5,6,7};

void lcd_gpio_init() {
    for (int i = 0; i < 8; i++) {
        gpio_init(lcd_data_pins[i]);
        gpio_set_dir(lcd_data_pins[i], true);
    }
    gpio_init(LCD_RS);  gpio_set_dir(LCD_RS, true);
    gpio_init(LCD_CS);  gpio_set_dir(LCD_CS, true);
    gpio_init(LCD_WR);  gpio_set_dir(LCD_WR, true);
    gpio_init(LCD_RD);  gpio_set_dir(LCD_RD, true);
    gpio_put(LCD_RD, 1); // RD en alto

    gpio_put(LCD_CS, 0);
    gpio_put(LCD_WR, 1);
}

void lcd_write_bus(uint8_t value) {
    for (int i = 0; i < 8; i++) {
        gpio_put(lcd_data_pins[i], (value >> i) & 1);
    }
    gpio_put(LCD_WR, 0);
    sleep_us(2);
    gpio_put(LCD_WR, 1);
}

void lcd_write_cmd(uint8_t cmd) {
    gpio_put(LCD_RS, 0);
    lcd_write_bus(cmd);
}

void lcd_write_data(uint8_t data) {
    gpio_put(LCD_RS, 1);
    lcd_write_bus(data);
}

void lcd_reset() {
    lcd_write_cmd(0x01); // Software Reset
    sleep_ms(120);
}

void lcd_init() {
    lcd_reset();

    lcd_write_cmd(0x28); // Display OFF
    lcd_write_cmd(0x11); // Sleep OUT
    sleep_ms(120);

    lcd_write_cmd(0x3A); // Pixel Format
    lcd_write_data(0x55); // RGB565

    lcd_write_cmd(0x36); // Memory Access Control
    lcd_write_data(0x08); // BGR, portrait

    lcd_write_cmd(0x29); // Display ON
    sleep_ms(20);
}

void lcd_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    lcd_write_cmd(0x2A);
    lcd_write_data(x0 >> 8); lcd_write_data(x0 & 0xFF);
    lcd_write_data(x1 >> 8); lcd_write_data(x1 & 0xFF);

    lcd_write_cmd(0x2B);
    lcd_write_data(y0 >> 8); lcd_write_data(y0 & 0xFF);
    lcd_write_data(y1 >> 8); lcd_write_data(y1 & 0xFF);

    lcd_write_cmd(0x2C);
}

void lcd_fill_color(uint16_t color) {
    lcd_set_window(0, 0, 239, 399); // pantalla completa ILI9327

    uint8_t high = color >> 8;
    uint8_t low  = color & 0xFF;

    for (int i = 0; i < 240 * 400; i++) {
        lcd_write_data(high);
        lcd_write_data(low);
    }
}

int main() {
    stdio_init_all();
    lcd_gpio_init();
    lcd_init();

    while (true) {
        lcd_fill_color(0xF800); // rojo
        sleep_ms(1000);
        lcd_fill_color(0x07E0); // verde
        sleep_ms(1000);
        lcd_fill_color(0x001F); // azul
        sleep_ms(1000);
    }
}